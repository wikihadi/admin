<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PressesLinkOptions extends Model
{
    protected $guarded=[];
}
