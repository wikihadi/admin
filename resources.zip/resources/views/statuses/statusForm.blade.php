<form  method="post" action="{{ route('status.store') }}">
    @csrf
    <div class="row collapse form-group advanced w-100">
        <div class="col-md-6">
            <select name="task_id" class="form-control form-control-sm">
                <option selected="selected" value="">به کار</option>
                @foreach($myTasksStatus as $myTask)
                    <option value="{{ $myTask->id }}">{{ $myTask->title }}</option>

                @endforeach


            </select>
        </div>
        <div class="col-md-6">
            <select name="to_user" class="form-control form-control-sm">
                <option selected="selected" value="">به شخص</option>
                @foreach($usersStatus as $user)
                    <option value="{{ $user->id }}">{{ $user->name }}</option>

                @endforeach


            </select>
        </div>
    </div>
    <div class="input-group">
        <input type="text" class="form-control InputToFocus" name="content" autocomplete="off" placeholder=".....">
        <div class="input-group-append">
            <input type="hidden" name="user_id" value="{{Auth::id()}}">
            <button class="btn btn-dark btn-add" type="submit"><i class="fa fa-check"></i></button>
        </div>
    </div>

</form>

<button class="btn btn-link float-right" data-toggle="collapse" data-target=".advanced" type="button"><i class="fa fa-bars"></i></button>
<form action="" class="form-inline">
    <button class="btn btn-link" data-toggle="collapse" data-target="" type="button"><i class="fa fa-play"></i></button>

</form>
