<div class="col-sm-12">
    <div class="col-3 m-auto m-3 p-5 bg-white collapse fade" style="border-radius: 30px;" id="demo">

        <div class="row">
            <div class="col-3 text-center"><a href="/tasks"><small>طراحی</small></a></div>
            <div class="col-3 text-center"><small>پیگیری</small></div>
            <div class="col-3 text-center"><small>چاپ</small></div>
            <div class="col-3 text-center"><a href="/done"><small>پایان یافته</small></a></div>

            {{--<div class="col-12 my-4 position-relative">--}}

            {{--<div class="bullett" style="left: 0px"></div>--}}
            {{--<div class="bullett" style="left: 31%;"></div>--}}
            {{--<div class="bullett" style="left: 61%;"></div>--}}
            {{--<div class="bullett" style="right: 0;"></div>--}}

            {{--<input id="slider-range" type="range" min="1" max="4" value="3" class="position-absolute" data-rangeslider style="z-index: 100!important; left: 0" disabled="">--}}
            {{--</div>--}}


        </div>

    </div>
</div>

{{--<div class="m-3 p-5 bg-white" style="border-radius: 30px;">--}}
{{--<div class="row">--}}
{{--<div class="form-group col-4 text-left">--}}
{{--جامع--}}
{{--</div>--}}
{{--<div class="form-group col-4 text-center">--}}

{{--<label class="switch">--}}
{{--<input type="checkbox" name="" id="switchMode" onclick="--}}


{{--var checkBoxes = $('#startDate');--}}
{{--checkBoxes.prop('checked', !checkBoxes.prop('checked'));--}}
{{--" checked>--}}
{{--<span class="slider round"></span>--}}

{{--</label>--}}



{{--</div>--}}
{{--<div class="form-group col-4 text-right">--}}
{{--ساده--}}
{{--</div>--}}
{{--</div>--}}
{{--<div class="row">--}}
{{--<div class="col-2 text-left"><input id="startDate" type="checkbox" class="" onclick="--}}
{{--$('.startDate').toggleClass('d-none');"></div>--}}
{{--<div class="col-10"><label for="startDate">تاریخ شروع</label></div>--}}
{{--<div class="col-2 text-left"><input type="checkbox" class=""></div>--}}
{{--<div class="col-10">تاریخ شروع</div>--}}
{{--<div class="col-2 text-left"><input type="checkbox" class=""></div>--}}
{{--<div class="col-10">تاریخ شروع</div>--}}
{{--<div class="col-2 text-left"><input type="checkbox" class=""></div>--}}
{{--<div class="col-10">تاریخ شروع</div>--}}
{{--</div>--}}
{{--</div>--}}
{{--</div>--}}
