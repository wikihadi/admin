<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
    @include('admincore.sidebar.user')

    <!-- Sidebar Menu -->

        @include('admincore.sidebar.menu')
    </div>
</aside>
<!-- /.control-sidebar -->