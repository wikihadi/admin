<div class="fixed-bottom collapse bg-light" id="crateStatus2">
    @include('statuses.statusForm')
</div>