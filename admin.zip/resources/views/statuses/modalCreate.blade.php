
{{--<div class="modal fade" id="crateStatus" role="dialog" style="z-index: 3001;" dir="rtl">--}}
    {{--<div class="modal-dialog modal-lg">--}}
        {{--<div class="modal-content">--}}
            {{--<div class="modal-header">--}}
                {{--<button type="button" class="close" data-dismiss="modal">&times;</button>--}}
                {{--<h4 class="modal-title">وضعیت</h4>--}}
            {{--</div>--}}
            {{--<div class="modal-body">--}}
                {{--<form id="frmAddTask">--}}
                    {{--@csrf--}}
                    {{--<div class="form-group">--}}
                        {{--<input type="text" class="form-control" name="share_name"/>--}}
                    {{--</div>--}}
                    {{--<button class="btn btn-info" id="btn-add" type="button" value="add">--}}
                        {{--بزن بریم</button>--}}
                {{--</form>--}}
                {{--<form id="myForm">--}}
                           {{--<div class="form-group">--}}
                        {{--<input type="text" class="form-control" id="comment" name="comment">--}}
                    {{--</div>--}}
                    {{--<button class="btn btn-primary btn-block"  id="ajaxSubmit">Add</button>--}}
                {{--</form>--}}
                {{--<div class="form-group row add">--}}
                    {{--<div class="col-md-8">--}}
                        {{--<input type="text" class="form-control" id="comment" name="comment"--}}
                               {{--required>--}}
                        {{--<p class="error text-center alert alert-danger hidden"></p>--}}
                    {{--</div>--}}
                    {{--<div class="col-md-4">--}}
                        {{--<button class="btn btn-primary" type="submit" id="add">--}}
                            {{--<span class="glyphicon glyphicon-plus"></span> ADD--}}
                        {{--</button>--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}
            {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</div>--}}
