<div id="crateStatus" class="modal fade" role="dialog" style="padding-right: 0!important;">
    <div class="modal-dialog modal-dialog-centered">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">اعلام وضعیت...</h4>
            </div>
            <div class="modal-body">
                @include('statuses.statusForm')
            </div>



        </div>

    </div>
</div>
