<div class="row">
    <div class="col-md-9">
        <div class="card border-0 d-none d-lg-block animated fadeIn delay-1s" style="box-shadow: none">
            <div class="card-header" style="border-bottom: 0">
                <div class="row">
                    <div class="d-none d-lg-block col-lg-1 text-right">اولویت</div>
                    <div class="d-none d-lg-block col-12 col-md-3 text-center text-md-right"></div>
                    <div class="d-none d-lg-block col-lg-2 text-center">برند</div>
                    <div class="d-none d-lg-block col-lg-2 text-center">نوع</div>
                    <div class="d-none d-lg-block col-lg-2 text-center">برای</div>
                    {{--<div class="d-none d-xl-block col-xl-1 text-center">قطع</div>--}}
                    {{--<div class="d-none d-xl-block col-xl-1 text-center">متریال</div>--}}
                    <div class="d-none d-lg-block col-lg-2 text-center"></div>




                </div>
            </div>

        </div>
    </div>
</div>