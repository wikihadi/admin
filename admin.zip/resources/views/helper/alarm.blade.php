{{--<div class="alert alert-dark card-border animated shake delay-2s" dir="rtl">  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>{{$user->name}} عزیز! آپدیت جدید انجام شد. تغییرات را ببینید<a--}}
            {{--href="/posts/4" class="btn btn-info">مطالعه بیشتر</a></div>--}}
