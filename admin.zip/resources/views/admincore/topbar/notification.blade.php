<li class="nav-item dropdown">
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="fa fa-bell-o"></i>
        <span class="badge badge-warning navbar-badge">15</span>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-left">
        <span class="dropdown-item dropdown-header">15</span>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item">
            <i class="fa fa-envelope ml-2"></i> 15 پیام جدید
            <span class="float-left text-muted text-sm">3 دقیقه</span>
        </a>


        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item dropdown-footer">مشاهده همه</a>
    </div>
</li>
