<ul class="navbar-nav">
    {{--<li class="nav-item">--}}
        {{--<a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>--}}
    {{--</li>--}}
    {{--<li class="nav-item d-none d-sm-inline-block">--}}
        {{--<a href="/" class="nav-link">داشبورد</a>--}}
    {{--</li>--}}
    {{--<li class="nav-item d-none d-sm-inline-block">--}}
        {{--<a href="/tasks" class="nav-link">الویت ها</a>--}}
    {{--</li>--}}
</ul>