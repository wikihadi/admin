    



<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-fixed-left navbar-minimal animate" role="navigation">
        <div class="navbar-toggler animate">
            <span class="menu-icon"></span>
        </div>
        <ul class="navbar-menu animate">
            <li>
                <a href="#about-us" class="animate">
                    <span class="desc animate"> Who We Are </span>
                    <span class="glyphicon glyphicon-user"></span>
                </a>
            </li>
            <li>
                <a href="#blog" class="animate">
                    <span class="desc animate"> What We Say </span>
                    <span class="glyphicon glyphicon-info-sign"></span>
                </a>
            </li>
            <li>
                <a href="#contact-us" class="animate">
                    <span class="desc animate"> How To Reach Us </span>
                    <span class="glyphicon glyphicon-comment"></span>
                </a>
            </li>
        </ul>
    </nav>

    <main class="py-4" >

    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <?php if(auth()->check() && auth()->user()->hasRole('writer')): ?>
                        I'm a writer!
                        <?php else: ?>
                            I'm not a writer...
                            <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>