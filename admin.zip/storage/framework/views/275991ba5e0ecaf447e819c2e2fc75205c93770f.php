<div class="col-sm-12">
    <div class="col-3 m-auto m-3 p-5 bg-white collapse fade" style="border-radius: 30px;" id="demo">

        <div class="row">
            <div class="col-3 text-center"><a href="/tasks"><small>طراحی</small></a></div>
            <div class="col-3 text-center"><small>پیگیری</small></div>
            <div class="col-3 text-center"><small>چاپ</small></div>
            <div class="col-3 text-center"><a href="/done"><small>پایان یافته</small></a></div>

            

            
            
            
            

            
            


        </div>

    </div>
</div>







































