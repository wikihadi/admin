<?php $__env->startSection('css'); ?>

    <style>
        body, .content-wrapper, .main-heade, .bg-white ,footer{
            background: #2b2a2e!important;
        }
        .border-bottom{
            border-bottom: none!important;
        }
        .nav-link{
            color: #888!important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="col-md-10 col-lg-8 col-xl-6 m-auto mt-sm-5" style="">
        <div class="col-md-10 col-lg-8 col-xl-6 m-auto">
            <table class="table table-light text-dark table-striped">

                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="/jobs/<?php echo e($comment->user->id); ?>"><img class="img-circle" style="width: 50px"
                                 src="/storage/avatars/<?php echo e($comment->user->avatar); ?>" title="<?php echo e($comment->user->name); ?>"/></a></td>

                        <td class="text-left"><small dir="ltr"
                                    class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small><a target="_blank" class="btn btn-link" href="/tasks/<?php echo e($comment->task_id); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                    <tr>

                        <td colspan="2">
                            <?php $__currentLoopData = $tasks->where('id',$comment->task_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/tasks/<?php echo e($comment->task_id); ?>" target="_blank"><small><?php echo e($t->title); ?></small></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class=""><?php echo e($comment->comment); ?></div>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>