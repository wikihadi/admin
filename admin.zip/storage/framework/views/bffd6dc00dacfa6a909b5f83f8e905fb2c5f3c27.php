<?php $__env->startSection('content'); ?>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

        <div class="col-md-10 m-auto">
    <table class="table table-striped">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
            <a class="btn" href="<?php echo e(route('roles.create')); ?>"><i class="fa fa-2x fa-plus-circle"></i></a>
        <?php endif; ?>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><a class="btn" href="<?php echo e(route('roles.show',$role->id)); ?>"><?php echo e($role->name); ?></a></td>
                <td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                        <a class="btn text-muted" href="<?php echo e(route('roles.edit',$role->id)); ?>"><i class="fa fa-lg fa-pencil"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                        <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                        <?php echo Form::submit('حذف', ['class' => 'btn text-danger btn-link']); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

        </div>
    <?php echo $roles->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>