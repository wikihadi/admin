<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('helper.css.mainTasksCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div class="col-sm-12">

        <div class="m-3 p-5 bg-white" style="border-radius: 30px;">
            <?php if($task->isDone == 1): ?>
            <div class="alert-info alert text-center">این کار توسط کاربر <?php echo e($task->done_user_id); ?> در تاریخ <?php echo e($task->done_date); ?> به اتمام رسیده است</div>
            <?php endif; ?>
            <?php if(isset($taskMeter) && $taskMeter->end == 0): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>شروع کار</strong> این کار در حال انجام است
                    <a href="/tasks/<?php echo e($task->id); ?>/end"
                       class="btn btn-link my-2 text-dark">توقف زمان کار</a>
                    <strong><?php echo e($taskMeter->created_at); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            <h1 class="text-center"><?php echo e($task->title); ?></h1>
            <div class="d-md-flex justify-content-center">
                    <?php if($task->type && $task->type != "سایر"): ?>
                        <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="نوع کار"
                                data-placement="bottom"><?php echo e($task->type); ?></button> <?php endif; ?>
                    <?php if($task->type && $task->brand != "سایر"): ?>
                        <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="برند"
                                data-placement="bottom"><?php echo e($task->brand); ?></button> <?php endif; ?>
                    <?php if($task->type && $task->forProduct != "سایر"): ?>
                        <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="محصول"
                                data-placement="bottom"><?php echo e($task->forProduct); ?></button> <?php endif; ?>
                    <?php if($task->type && $task->material != "سایر"): ?>
                        <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="متریال"
                                data-placement="bottom"><?php echo e($task->material); ?></button> <?php endif; ?>
                    <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="نظر"
                            data-placement="bottom"><?php echo e($task->commentCount); ?> <i class="fa fa-lg fa-commenting-o"></i></button>
                    <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="مشاهده"
                            data-placement="bottom"><?php echo e($task->viewCount); ?> <i class="fa fa-lg fa-eye"></i></button>
                    <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="<?php echo e($dead); ?> روز دیگر"
                            data-placement="bottom"><?php echo e($dead); ?>

                        <i class="fa <?php if($dead < 0 ): ?> fa-hourglass-end <?php elseif($dead <= 3): ?> fa-hourglass-half <?php else: ?> fa-hourglass-start <?php endif; ?> "></i>
                    </button>
                    <?php if($task->reTask === 1): ?>

                        <button class="btn btn-sm btn-link text-muted" data-toggle="tooltip" title="Clone"
                                data-placement="bottom">
                            <i class="fa fa-clone"></i>
                        </button>
                    <?php endif; ?>

            </div>
<div class="row">
            <div class="text-right col">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-link"><i class="fa fa-home"></i></a>
                <a href="/tasks" class="btn btn-link" title="My Tasks"><i class="fa fa-list-ol"></i></a>

            </div>
            <div class="text-left col">

                
                <a class="btn btn-link" data-toggle="collapse" href=".collapse"><i class="fa fa-arrows-alt"></i></a>
                <?php if(isset($taskMeter) && $taskMeter->end == 1): ?>
                    <a href="/tasks/<?php echo e($task->id); ?>/start" class="btn btn-link"><i class="fa fa-play"></i></a>

                <?php elseif(isset($taskMeter) && $taskMeter->end == 0): ?>
                    <a href="/tasks/<?php echo e($task->id); ?>/end" class="btn btn-link"><i class="fa fa-pause"></i></a>
                    <?php else: ?>
                    <a href="/tasks/<?php echo e($task->id); ?>/start" class="btn btn-link"><i class="fa fa-play"></i></a>

                <?php endif; ?>
            </div>
            </div>

            <div class="row">
                <!------------------------------------------------------------------>
                <div class="col-lg-6 order-12 order-md-1">
                    <div class="card card-border">

                        <div class="

                        <?php if($dead < 0 ): ?>
                                card-danger bg-danger
<?php elseif($dead <= 3): ?>
                                card-danger bg-warning

<?php else: ?>

                                bg-info

<?php endif; ?>

                                card-header
                                card-border" data-toggle="collapse" href="#desc">
                            <div class="">+ مشخصات</div>


                        </div>
                        <div id="desc" class="collapse show noShow" data-parent="#accordion">
                            <div class="card-body">


                                <div class="row">
                                    <div class="col-sm-12 text-center">
                                        <img src="/storage/uploads/<?php echo e($task->pic); ?>" class="img-fluid" alt="">
                                    </div>
                                    <div class="col-sm-12 table-responsive">

                                        <table class="table table-borderless table-striped" style="width: 100%">

                                            <tr>
                                                <td>کد پروژه</td>
                                                <td><?php echo e($task->id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>عنوان</td>
                                                <td><?php echo e($task->title); ?></td>
                                            </tr>

                                            <tr>
                                                <td>شروع پروژه</td>
                                                <td><?php echo e($task->jStartDate); ?></td>
                                            </tr>
                                            <tr>
                                                <td>پایان پروژه</td>
                                                <td><?php echo e($task->jDeadline); ?></td>
                                            </tr>
                                            <tr>
                                                <td>فاز پروژه</td>
                                                <td><?php echo e($task->status); ?></td>
                                            </tr>
                                            <tr>
                                                <td>تعداد نظرات</td>
                                                <td><?php echo e($task->commentCount); ?></td>
                                            </tr>
                                            <tr>
                                                <td>ایجاد کننده</td>
                                                <td>
                                                    <img src="/storage/avatars/<?php echo e($admin->avatar); ?>" alt="" class="img-circle mx-1" style="object-fit: cover; width: 30px;height: 30px; border: 1px solid #a9a9a9;" title="<?php echo e($admin->name); ?>" data-toggle="tooltip">

                                                    </td>
                                            </tr>
                                            <tr>
                                                <td>تیم کاری</td>
                                                <td class="d-flex">
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="mx-1">
                                                            <img src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="" class="img-circle" style="object-fit: cover; width: 30px;height: 30px; border: 1px solid #a9a9a9;" title="<?php echo e($u->name); ?>" data-toggle="tooltip">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </table>


                                    </div>

                                   </div>
                                <div class="col-sm-3"></div>
                                <div class="col-sm-3"></div>
                                <div class="col-sm-12">

                                </div>
                            </div>
                        </div>

                    </div>

                    <div id="contentCard" class="card card-border">

                        <div class="bg-light card-header card-border" data-toggle="collapse" href="#content">
                            <div class="">+ توضیحات
                            </div>


                        </div>
                        <div id="content" class="collapse noShow" data-parent="#accordion">
                            <div class="card-body">


                                <div class="col-sm-12">
                                    <p class="text-justify">
                                        <?php echo e($task->content); ?>


                                    </p>


                                </div>
                            </div>


                        </div>
                    </div>

                </div>
                <!------------ Comment ------------------------------------------------------->
                <div class="col-lg-6 order-11 order-md-2">
                    <div id="commentCard" class="card card-border">

                        <div class="bg-secondary card-header card-border" data-toggle="collapse" href="#comments">
                            <div class="row">
                                <div class="">+ وضعیت
                                </div>


                            </div>


                        </div>
                        <div id="comments" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-10 m-auto">

                                        <div class="comment-wrapper">
                                            <div class="panel panel-info">
                                                <div class="d-flex justify-content-center">
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mx-1 text-center">
                                                        <img src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="" class="img-circle" style="object-fit: cover; width: 40px;height: 40px; border: 1px solid #a9a9a9;" title="<?php echo e($u->name); ?>" data-toggle="tooltip">
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <p class="text-justify bg-light-gradient p-2">
                                                    توضیحات:
                                                    <?php echo e($task->content); ?>


                                                </p>
                                                <div class="panel-heading">
                                                    <?php echo e($task->commentCount); ?> نظر
                                                </div>
                                                <div class="panel-body">

                                                    <form method="post" action="<?php echo e(route('comments.store')); ?>">
                                                        <div class="form-group">
                                                            <?php echo csrf_field(); ?>
                                                            
                                                                      
                                                            
                                                            
                                                                <textarea id="" name="comment" class="form-control" rows="3" placeholder="به نظر من..."></textarea>
                                                                

                                                                
                                                                    <button class="btn btn-success btn-block" type="submit">ثبت نظر</button>
                                                                
                                                            
                                                        </div>

                                                        <input type="hidden" name="user_id"
                                                               value="<?php echo e(Auth::user()->id); ?>">
                                                        <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                                        
                                                            
                                                        
                                                    </form>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <ul class="media-list">


                                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <li class="media">
                                                                <a href="#" class="pull-left ml-3">
                                                                    <img class="img-circle" style=""
                                                                         src="/storage/avatars/<?php echo e($comment->user->avatar); ?>"/>
                                                                </a>
                                                                <div class="media-body">
                                                                    <span class="text-muted pull-left">
                                                                        <small dir="ltr" class="text-muted" title="<?php echo e($comment->jCreated_at); ?>"  data-toggle="tooltip" data-placement="right"><?php echo e($comment->diff); ?></small>

                                                                    </span>
                                                                    <strong class="text-success"><?php echo e($comment->user->name); ?></strong>
                                                                    <div class="clearfix"></div>
                                                                    <div style="white-space: pre-wrap;"><?php echo e($comment->comment); ?></div>
                                                                    <div class="text-left">
                                                                    <?php if($comment->diffM < 5): ?>
                                                                        

                                                                            

                                                                            
                                                                            
                                                                            
                                                                            <a class="btn btn-link my-2 text-muted" href="/comments/<?php echo e($comment->id); ?>/edit"><i class="fa fa-edit"></i></a>
                                                                        
                                                                        <?php endif; ?>
                                                                    </div>

                                                                </div>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>


                            </div>


                        </div>
                    </div>

                    <!------------ setting ------------------------------------------------------->
                    <div id="settingCard" class="card card-border d-none d-md-block">

                        <div class="bg-light card-header card-border" data-toggle="collapse" href="#setting">
                            <div class="">+ تنظیمات
                            </div>


                        </div>
                        <div id="setting" class="collapse" data-parent="#accordion">
                            <div class="card-body">
                            <div class="d-flex justify-content-around">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-delete')): ?>

                                        <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="urlP" value="<?php echo e($urlP); ?>">

                                            <button class="btn btn-danger my-2" type="submit">حذف</button>
                                        </form>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-edit')): ?>

                                <a href="/tasks/<?php echo e($task->id); ?>/edit"
                                           class="btn btn-warning my-2">ویرایش</a>

                                <?php endif; ?>
<?php if($task->isDone == 1): ?>
                                    <?php if(auth()->check() && auth()->user()->hasRole('admin|designer')): ?>

                                <form action="<?php echo e(route('tasks.done', $task->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="0" name="isDone">
                                    <input type="hidden" value="<?php echo e($task->id); ?>" name="id">
                                    <button class="btn btn-warning my-2" type="submit">برگردان به بخش اجرایی</button>
                                </form>
                                    <?php endif; ?>
<?php else: ?>
                                    <?php if(auth()->check() && auth()->user()->hasRole('modir')): ?>
                                    <?php else: ?>

                                    <form action="<?php echo e(route('tasks.done', $task->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="1" name="isDone">
                                        <input type="hidden" value="<?php echo e($user->id); ?>" name="done_user_id">
                                        <input type="hidden" value="<?php echo e($task->id); ?>" name="id">
                                        <button class="btn btn-success my-2" type="submit">اتمام کار</button>
                                    </form>
                                        <?php endif; ?>
    <?php endif; ?>
                            </div>
                            </div>


                        </div>
                    </div>

                    <!------------ timeSheet ------------------------------------------------------->
                    <?php if(count($taskMeters) > 0): ?>
                    <div id="settingCard" class="card card-border d-none d-md-block">

                        <div class="bg-light card-header card-border" data-toggle="collapse" href="#timing">
                            <div class="">+ زمان کار
                            </div>


                        </div>
                        <div id="timing" class="collapse" data-parent="#accordion">
                            <div class="card-body">
                                    <a href="/tasks/<?php echo e($task->id); ?>/start" class="badge table-success"><i class="fa fa-2x fa-play-circle-o text-muted"></i></a>
                                <a href="/tasks/<?php echo e($task->id); ?>/end" class="badge table-secondary"><i class="fa fa-2x fa-pause-circle-o text-muted"></i></a>
                                <table class="table table-hover text-center">
                                    <tr>
                                        <td>تاریخ</td>
                                        <td>ساعت</td>
                                        <td>کارکرد</td>
                                    </tr>
                                    <?php
                                    $totalH = 0;
                                    $totalM = 0;
                                    $totalS = 0;
                                    ?>

                                    <?php $__currentLoopData = $taskMeters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($tm->end == 0): ?>
                                            <?php
                                            $dateDiff = "-";
                                            ?>
                                    <tr class="table-success">
                                        <?php else: ?>


                                        <?php

                                        //$dateDiff = $tm->diffM;
                                        /*$tmm = $tm->diffM % 60;
                                        $tmmd = floor($tm->diffM / 60);


                                        $tms = $tm->diffS % 60;
                                        $tmsd = floor($tm->diffS / 60);

                                        $tmmf = $tmsd + $tms;
                                        $tmhf = $tm->diffH + $tmmd;*/


                                        $tms = $tm->diffS % 60;
                                        $tmm = floor($tm->diffS / 60) % 60;
                                        $tmh = floor(floor($tm->diffS / 60) / 60);



                                        $dateDiff = $tmh . ":" . $tmm . ":" . $tms;


                                        $totalS += $tm->diffS;





                                            ?>
                                    <tr class="table-secondary">
                                        <?php endif; ?>
                                        <td><?php echo e($tm->jDate); ?></td>
                                        <td><?php echo e(date('H:i:s', strtotime($tm->created_at))); ?></td>
                                        <td><?php echo e($dateDiff); ?></td>
                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total = floor(floor($totalS / 60) / 60) . ":" . floor($totalS / 60) % 60 . ":" . $totalS % 60;
                                        ?>
                                            <tr class="table-info">
                                                <td colspan="2">مجموع</td>
                                                <td><?php echo e($total); ?></td>
                                            </tr>
                                </table>

                            </div>


                        </div>
                    </div>
                        <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.js"></script>
<script>
    $(function() {
        $('#summernote').summernote();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>