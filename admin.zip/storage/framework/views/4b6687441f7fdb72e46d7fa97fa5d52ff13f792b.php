<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('helper.css.createTaskCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-8 m-auto">
        <?php echo $__env->make('helper.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card uper">
            <div class="card-header">
                <div class="float-right">ثبت کار جدید</div>
                <div class="float-left">
                    طراحی
                    <label class="switch">
                        <input type="checkbox" onchange="formToggle()">
                        <span class="slider"></span>
                    </label>
                    اجرایی
                    <span></span>
                </div>
            </div>
            <div class="card-body">
                <?php echo $__env->make('helper.createTask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
    <?php echo $__env->make('helper.js.createTaskJs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>