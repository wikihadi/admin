<?php $__env->startSection('css'); ?>

    <style>
        body, .content-wrapper, .main-heade, .bg-white ,footer{
            background: #2b2a2e!important;
        }
        .border-bottom{
            border-bottom: none!important;
        }
        .nav-link{
            color: #888!important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="col-md-10 col-lg-8 col-xl-6 m-auto mt-sm-5" style="">
        <div class="col-md-10 col-lg-8 col-xl-6 m-auto">
            <table class="table table-light text-dark table-striped">

                    <tr>
                        <td><img class="img-circle" style="width: 50px"
                                 src="/storage/avatars/<?php echo e($comment->user->avatar); ?>" title="<?php echo e($comment->user->name); ?>"/></td>

                        <td class="text-left"><small dir="ltr"
                                                     class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small><a target="_blank" class="btn btn-link" href="/tasks/<?php echo e($comment->task_id); ?>"><i class="fa fa-arrow-left"></i></a></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                        <form class="" action="<?php echo e(route('comments.update',$comment->id)); ?>" method="post">
                            <?php echo method_field('PATCH'); ?>
                            <?php echo csrf_field(); ?>
                            <textarea name="comment" class="form-control"><?php echo e($comment->comment); ?></textarea>
                            <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
                            <input type="hidden" value="<?php echo e($comment->task_id); ?>" name="task_id">
                            <div class="text-left"><button class="btn btn-link my-2 text-muted" type="submit"><i class="fa fa-edit"></i></button></div>

                        </form>
                        </td>
                    </tr>

            </table>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>