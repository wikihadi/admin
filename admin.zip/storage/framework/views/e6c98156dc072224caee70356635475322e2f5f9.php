<?php $__env->startSection('css'); ?>

    <style>
        body, .content-wrapper, .main-heade, .bg-white ,footer{
            background: #2b2a2e!important;
        }
        .border-bottom{
            border-bottom: none!important;
        }
        .nav-link{
            color: #888!important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="app">
<tasks-component></tasks-component>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
<script src="/js/app.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>