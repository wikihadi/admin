<form enctype="multipart/form-data" method="post" action="<?php echo e(route('tasks.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="form-group col-sm-12 formChange" style="display: none">

            <div class="alert alert-warning">شما در حال ساخت یک پروژه در واحد طراحی هستید.</div>

        </div>
        <div class="form-group col-sm-12 formChange">
            <label for="title">عنوان</label>
            <input type="text" class="form-control" id="taskName" name="title" placeholder="عنوان کامل کار" value="ندارد" />

        </div>
        <div class="form-group col-sm-4">
            <label for="">نوع</label>
            <div class="selectType">
                <select name="isType" class="form-control select2 selectType">

                    <option id="type1"  value="سایر" selected>سایر</option>


                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->title); ?>"><?php echo e($type->title); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>
            </div>
            <input  type="text" class="form-control selectType" name="isType2" placeholder="نوع جدید را در وارد کنید" style="display: none;">

            <input type="checkbox" onchange="selectToggle()">نوع جدید

        </div>

        <div class="form-group col-sm-2">
            <label for="">برند</label>
            <select name="brand" class="form-control select2">
                <option selected="selected" value="سایر">سایر</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->title); ?>"><?php echo e($u->title); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </select>

        </div>

        <div class="form-group col-sm-3">
            <label for="">برای</label>
            
            

            
            

            


            
            <input type="text" class="form-control" name="forProduct" value="سایر">

        </div>

        <div class="form-group col-sm-3">
            <label for="">متریال</label>
            <input type="text" name="material" class="form-control" value="سایر">
            
            
            
            

            


            

        </div>














        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <div class="form-group col-sm-2">


            <label for="title">الویت</label>
            <select class="form-control" name="orderTask">
                <option value="10">10</option>
                <option value="9">9</option>
                <option value="8">8</option>
                <option value="7">7</option>
                <option value="6">6</option>
                <option value="5">5</option>
                <option value="4">4</option>
                <option value="3">3</option>
                <option value="2">2</option>
                <option value="1">1</option>
            </select>
            
            
        </div>
        <div class="form-group col-sm-2">


            <label for="title">وزن (ارزش)</label>

            <select class="form-control" name="weight">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>

                <option value="9">9</option>

                <option value="10">10</option>
            </select>
            
            
        </div>
        <?php else: ?>
            <input type="hidden" name="orderTask" value="10">
            <input type="hidden" name="weight" value="1">
            <?php endif; ?>

            <div class="form-group col-sm">
                <label for="deadline">شروع</label>
                <div class="input-group">
                    <input readonly type="text" class="form-control pdp-data-jdate text-center" id="gStartDate" autocomplete="off" value="<?php echo e($jNow); ?>"/>
                    <input type="text"  name="startTime" class="form-control text-center timepicker">

                </div>
                <input type="hidden"  id="startDate" name="startDate" required/>
                
                
            </div>
            <div class="form-group col-sm">
                <label for="deadline">پایان</label>
                <div class="input-group">
                    <input readonly type="text" class="form-control pdp-data-jdate text-center" id="gEndDate" name="deadline1"
                           autocomplete="off" required value="<?php echo e($jNow); ?>"/>
                    <input type="text"  name="endTime"  class="form-control timepicker2 text-center">

                </div>
                <input type="hidden"  id="endDate" name="endDate"/>
                
                
            </div>
    </div>

    <div class="p-2 formChange text-left">
        <button data-toggle="collapse" href="#xtra" class="btn btn-sm btn-outline-dark" type="button">اندازه</button>
        

        
    </div>
    <div id="xtra" class="collapse row fade ">


        
        
        
        
        
        

        


        

        

        
        
        
        
        
        
        

        


        

        
        <div class="form-group col-sm-3">
            <label for="">عرض کار</label>
            <input type="number" class="form-control" name="dx" placeholder="عرض">
        </div>
        <div class="form-group col-sm-3">
            <label for="">طول کار</label>
            <input type="number" class="form-control" name="dy" placeholder="طول">
        </div>
        <div class="form-group col-sm-3">
            <label for="">عمق کار</label>
            <input type="number" class="form-control" name="dz" placeholder="عمق">
        </div>
        <div class="form-group col-sm-3">
            <label for="">واحد</label>
            <select name="dDesc" class="form-control">
                <option>انتخاب واحد</option>
                <option value="cm">سانتیمتر | cm</option>
                <option value="mm">میلیمتر | mm</option>
                <option value="px">پیکسل | px</option>
            </select>
            
        </div>
        <div class="form-group col-sm-6">
            
            

            
            
            

            


            
            

            
            
            
            
            

            
            

            


            
            

            


            
            

            
            
            
            
            
            
            
            
            


        </div>
    </div>







    <div class="form-group">
        <label for="">توضیحات پروژه </label>

        <textarea class="form-control" name="content"
                  placeholder="توضیحات کاری که باید انجام شود"  onfocus="clearContents(this);">ندارد</textarea>

    </div>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <div class="form-group col-sm-12" id="team">
        <label for="">تیم کاری - مخصوص ادمین</label>
        <select name="users[]" class="form-control select2" multiple>
            <option id="meInUsers" value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </select>

    </div>
    <?php else: ?>

        <input type="hidden" name="users[]" value="<?php echo e(Auth::user()->id); ?>" >


        <?php endif; ?>
        <div class="form-group">

            <?php if(auth()->check() && auth()->user()->hasRole('modir')): ?>
            <input type="hidden" name="pending" value="2">


        <?php else: ?>
                <label for="list1"><?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>در لیست <?php else: ?> در لیست خودم<?php endif; ?></label>
                <input id="list1" type="radio" name="pending" value="0" checked onclick="addTeam()">
                <label for="pending"><?php if(auth()->check() && auth()->user()->hasRole('admin')): ?> در لیست انتظار <?php else: ?> در لیست انتظار خودم <?php endif; ?></label>
                <input id="pending" type="radio" name="pending" value="1" onclick="addTeam()">
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <label for="pending2">کارهای آتی</label>
                <input id="pending2" type="radio" name="pending" value="2" onclick="clearTeam()">
                <?php endif; ?>
            <?php endif; ?>


        </div>
        <div class="row">



            <div class="form-group col-sm-6">
                <span>پروژه تکراری</span>

                <label class="switch">
                    <input type="checkbox" name="reTask" value="1">
                    <span class="slider"></span>
                </label>

            </div>
            <div class="form-group col-sm-6">






                <label for="pic" class="file-upload btn btn-info btn-block">تصویر شاخص پروژه

                    <input type="file" name="pic" id="pic" aria-describedby="fileHelp">
                    

                </label>
            </div>
        </div>

        <button type="submit" class="btn btn-success btn-block btn-lg">بفرست به لیست الویت ها</button>
        <button type="reset" class="btn btn-link">فرم تازه</button>
        <input type="hidden" name="urlP" value="<?php echo e($urlP); ?>">

</form>
