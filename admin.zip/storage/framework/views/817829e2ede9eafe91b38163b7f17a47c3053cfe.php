<?php $__env->startSection('content'); ?>







            <div class="row w-100">




                <div class="col-md-3">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success alert-block w-100">

                            <button type="button" class="close" data-dismiss="alert">×</button>

                            <strong><?php echo e($message); ?></strong>

                        </div>

                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                <?php endif; ?>
                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img style="object-fit: cover; height: 10rem; width: 10rem;"
                                     class="profile-user-img img-fluid img-circle"
                                     src="/storage/avatars/<?php echo e($user->avatar); ?>"
                                     alt="User profile picture"
                                     data-toggle="collapse"
                                     data-target="#demo"
                                     title="تغییر تصویر پروفایل"
                                >
                            </div>
                            <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>

                            <p class="text-muted text-center"><?php echo e($user->experience); ?></p>
                        <div id="demo" class="collapse">

                        <?php if(Auth::user()->id  == $user->id): ?>

                                <form action="" method="post" enctype="multipart/form-data">

                                    <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input type="file" class="form-control-file" name="avatar" id="avatarFile" aria-describedby="fileHelp">
                                            <small id="fileHelp" class="form-text text-muted">تا 2 مگابایت</small>
                                        </div>
                                        <div class="form-group row">
                                            <label for="name">نام و نام خانوادگی (فارسی)</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>">
                                        </div>

                                        
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                            
                                        
                                        
                                            
                                            
                                        
                                        <div class="form-group row">
                                            <label for="experience">یادداشت</label>
                                            <textarea name="experience" class="form-control"><?php echo e($user->experience); ?></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success btn-block">ویرایش پروفایل</button>
                                    </form>
                                    <?php endif; ?>
                        </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                    <!-- About Me Box -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">درباره من</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <strong><i class="fa fa-phone mr-1"></i>تلفن</strong>
                            <p class="text-muted">
                                <?php echo e($user->phone); ?>

                            </p>
                            <strong><i class="fa fa-mail-forward mr-1"></i> ایمیل</strong>

                            <p class="text-muted">
                                <?php echo e($user->email); ?>

                            </p>

                            

                            

                            

                            



                            

                            <p class="text-muted"><?php echo e($user->experience); ?></p>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="button" class="btn text-danger btn-link btn-block "
                                    data-toggle="collapse"
                                    data-target="#demo"
                            >ویرایش پروفایل<i class="fa fa-edit"></i></button>
                        </div>
                    </div>
                    




                        

                        


                                

                                    
                                
                                    
                                    
                                
                                
                                
                                
                                
                                
                                    
                                    
                                
                                
                                    
                                    
                                
                                
                                    
                                    
                                
                                

                                
                            
                        
                    
                    <!-- /.card -->
                </div>
                <!-- /.col -->
                <div class="col-md-9">

                    <div class="card">
                        
                            
                                
                                
                                
                            
                        
                            <div class="card-header"><div class="card-title">فعالیتهای اخیر من</div></div>
                            <div class="card-body">
                                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <!-- Post -->
                                    <div class="post w-100">
                                        <div class="">
                                            
                                            <span class="username">
                          <a href="/tasks/<?php echo e($task->id); ?>" target="_blank"><?php echo e($task->title); ?></a>
                          
                        </span>
                                            
                                        </div>
                                        <!-- /.user-block -->
                                        

                                        

                                        <p>
                                            
                                            
                                            
                          
                            
                          
                        
                                        </p>

                                    </div>
                                    <!-- /.post -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    


                                        
                                        

                                            
                                        



                                    
                                    



                            </div>

                    </div>

                </div>
                </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>