<nav class="mt-2 text-light">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
        <li class="nav-item">
            <a href="/" class="nav-link <?php if(Request::is('/')): ?> active text-light <?php endif; ?>">
                <i class="nav-icon fa fa-home"></i>
                <p>
                    داشبورد
                </p>
            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-list')): ?>
        <li class="nav-item has-treeview <?php if(Request::is('tasks*') || Request::is('jobs*')): ?> menu-open <?php endif; ?> ">
            <a href="#" class="nav-link <?php if(Request::is('tasks*') || Request::is('jobs*')): ?> active <?php endif; ?> ">
                <i class="nav-icon fa fa-tasks"></i>

                <p>
                    لیست کارها
                    <i class="right fa fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-allTasks')): ?>
                    <li class="nav-item">
                        <a href="/jobs" class="nav-link <?php if(Request::is('jobs*')): ?> active <?php endif; ?> ">
                            <i class="fa fa-list-ul nav-icon"></i>
                            <p>مشاهده کارها</p>
                        </a>
                    </li>
                <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-list')): ?>
                <li class="nav-item">
                    <a href="/tasks" class="nav-link <?php if(Request::is('tasks')): ?> active <?php endif; ?> ">
                        <i class="fa fa-list-ul nav-icon"></i>
                        <p>کارهای من</p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-create')): ?>

                <li class="nav-item">
                    <a href="/tasks/create" class="nav-link <?php if(Request::is('tasks/create')): ?> active <?php endif; ?> ">
                        <i class="fa fa-lg fa-plus-square nav-icon"></i>
                        <p>کار جدید</p>
                    </a>
                </li>
                    <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <li class="nav-item has-treeview <?php if(Request::is('users*') || Request::is('roles*')): ?> menu-open <?php endif; ?> ">
            <a href="#" class="nav-link <?php if(Request::is('users*') || Request::is('roles*')): ?> active <?php endif; ?> ">
                <i class="nav-icon fa fa-user"></i>

                <p>
                    مدیریت
                    <i class="right fa fa-angle-left"></i>
                </p>
            </a>
            <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="/users" class="nav-link  <?php if(Request::is('users') || Request::is('users*   ')): ?> active <?php endif; ?> ">
                        <i class="fa fa-list-ul nav-icon"></i>
                        <p>کاربران</p>
                    </a>
                </li>

                
                    
                        
                        
                    
                
                <li class="nav-item">
                    <a href="/brands" class="nav-link  <?php if(Request::is('brands*')): ?> active <?php endif; ?> ">
                        <i class="fa fa-500px nav-icon"></i>
                        <p>برند ها</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/types" class="nav-link  <?php if(Request::is('types*')): ?> active <?php endif; ?> ">
                        <i class="fa fa-tree nav-icon"></i>
                        <p>نوع کار</p>
                    </a>
                </li>
                
                    
                        
                        
                    
                
                
                    
                        
                        
                    
                

            </ul>
        </li>
        <?php endif; ?>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="nav-icon fa fa-th"></i>
                <p>
                    اطلاعیه و قوانین - بزودی
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="/tasks/28" class="nav-link">
                <i class="nav-icon fa fa-exclamation-triangle"></i>
                <p>
                    گزارش خطا
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                <i class="nav-icon fa fa-key"></i>
                    خروج
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
                

                
                
                    
                
            
        </li>
    </ul>
</nav>