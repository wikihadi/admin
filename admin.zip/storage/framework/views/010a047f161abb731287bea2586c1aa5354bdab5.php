<form enctype="multipart/form-data" method="post" action="<?php echo e(route('tasks.update', $task->id)); ?>">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="form-group col-sm-12 formChange" >
            <label for="title">عنوان</label>
            <input type="text" class="form-control" id="taskName" name="title" placeholder="عنوان کامل کار" value="<?php echo e($task->title); ?>"/>

        </div>
        <div class="form-group col-sm-4 formChange">
            <label for="">نوع</label>
            <input type="text" class="form-control" name="isType" value="<?php echo e($task->type); ?>">

        </div>

        <div class="form-group col-sm-2 formChange">
            <label for="">برند</label>
            <select name="brand" class="form-control select2">
                <option selected="selected" value="<?php echo e($task->brand); ?>"><?php echo e($task->brand); ?></option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->title); ?>"><?php echo e($u->title); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </select>

        </div>

        <div class="form-group col-sm-3 formChange">
            <label for="">برای</label>
            <input type="text" class="form-control" name="forProduct" value="<?php echo e($task->forProduct); ?>">

        </div>

        <div class="form-group col-sm-3 formChange">
            <label for="">متریال</label>
            <input type="text" name="material" class="form-control" value="<?php echo e($task->material); ?>">


        </div>
















        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <div class="form-group col-sm-1">


            <label for="title">الویت</label>
            <select class="form-control" name="orderTask">
                <option value="<?php echo e($task->orderTask); ?>"><?php echo e($task->orderTask); ?></option>
                <?php for($i = 10; $i >= 1; $i--): ?>
                    <?php if($i == $task->orderTask): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>

        </div>


        <div class="form-group col-sm-1">


            <label for="title">وزن (ارزش)</label>

            <select class="form-control" name="weight">
                <option value="<?php echo e($task->weight); ?>"><?php echo e($task->weight); ?></option>

                <?php for($i = 1; $i <= 10; $i++): ?>
                    <?php if($i == $task->weight): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
            
            
        </div>
        <?php else: ?>
            <input type="hidden" name="orderTask" value="<?php echo e($task->orderTask); ?>">
            <input type="hidden" name="weight" value="<?php echo e($task->weight); ?>">
            <?php endif; ?>

            <div class="form-group col-sm">
                <label for="deadline">شروع</label>
                <div class="input-group">
                    <input readonly type="text" class="form-control pdp-data-jdate text-center" id="gStartDate" autocomplete="off"
                           value="<?php echo e($jStart); ?>"/>
                    <input type="text"  name="startTime" class="form-control text-center timepicker" value="<?php echo e(date('H:i', strtotime($task->startDate))); ?>">

                </div>
                <input type="hidden" id="startDate" name="startDate"  value="<?php echo e(date('d-m-Y', strtotime($task->startDate))); ?>"/>


            </div>



            <div class="form-group col-sm">
                <label for="deadline">پایان</label>
                <div class="input-group">
                    <input readonly type="text" class="form-control pdp-data-jdate text-center" id="gEndDate" name="deadline1"
                           autocomplete="off" required value="<?php echo e($jEnd); ?>"/>
                    <input type="text"  name="endTime"  class="form-control timepicker2 text-center"  value="<?php echo e(date('H:i', strtotime($task->deadline))); ?>">

                </div>
                <input type="hidden"  id="endDate" name="endDate" value="<?php echo e(date('d-m-Y', strtotime($task->deadline))); ?>"/>
                
                
            </div>
    </div>

    <div class="p-2 formChange text-left">
        <label for="check">ثبت اندازه <input id="check" type="checkbox" class="" data-toggle="collapse" href="#xtra"></label>

    </div>
    <div id="xtra" class="collapse row fade ">



        <div class="form-group col-sm-3">
            <label for="">عرض کار</label>
            <input type="number" class="form-control" name="dx" placeholder="عرض" value="<?php echo e($task->dx); ?>">
        </div>
        <div class="form-group col-sm-3">
            <label for="">طول کار</label>
            <input type="number" class="form-control" name="dy" placeholder="طول" value="<?php echo e($task->dy); ?>">
        </div>
        <div class="form-group col-sm-3">
            <label for="">عمق کار</label>
            <input type="number" class="form-control" name="dz" placeholder="عمق" value="<?php echo e($task->dz); ?>">
        </div>
        <div class="form-group col-sm-3">
            <label for="">واحد</label>
            <select name="dDesc" class="form-control">
                <option value="<?php echo e($task->dDesc); ?>"><?php echo e($task->dDesc); ?></option>
                <option value="cm">سانتیمتر | cm</option>
                <option value="mm">میلیمتر | mm</option>
                <option value="px">پیکسل | px</option>
            </select>
        </div>

    </div>







    <div class="form-group">
        <label for="">توضیحات پروژه </label>

        <textarea class="form-control" name="content"
                  placeholder="توضیحات کاری که باید انجام شود"><?php echo e($task->content); ?></textarea>

    </div>

    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <div class="form-group col-sm-12">
        <label for="">تیم کاری</label>
        <select name="users[]" class="form-control select2" multiple>
            <?php $__currentLoopData = $users_old; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>" selected><?php echo e($u->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </select>

    </div>
    <?php else: ?>
        <input type="hidden" name="isUser" value="1">


        <?php endif; ?>
        <div class="form-group">

            <label for="list1">در لیست خودم</label>
            <input id="list1" type="radio" name="pending" onclick="addTeam()" value="0" <?php if($task->pending == 0): ?> checked <?php endif; ?>>
            <label for="pending">در لیست انتظار خودم</label>
            <input id="pending" type="radio" name="pending" onclick="addTeam()" value="1" <?php if($task->pending == 1): ?> checked <?php endif; ?>>
            <?php if(auth()->check() && auth()->user()->hasRole('admin|modir')): ?>
            <label for="pending2">در لیست انتظار</label>
            <input id="pending2" type="radio" name="pending" onclick="clearTeam()" value="2" <?php if($task->pending == 2): ?> checked <?php endif; ?>>
            <?php endif; ?>


        </div>

        <div class="row">



            
            

            
            
            
            

            
            <div class="form-group col-sm-12">
            <label for="pic" class="file-upload btn btn-light btn-block">تصویر شاخص پروژه - برای عدم تغییر رها کنید

            <input type="file" name="pic" id="pic" aria-describedby="fileHelp">

            </label>
            </div>
        </div>

        <input type="hidden" name="urlP" value="<?php echo e($urlP); ?>">
        <button type="submit" class="btn btn-success btn-block btn-lg">ثبت ویرایش</button>

</form>
