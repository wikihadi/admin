<?php $__env->startSection('content'); ?>

    <div class="col-md-8 m-auto">
        <button data-toggle="collapse" data-target="#addbrand" class="btn btn-link"><i class="fa fa-plus"></i></button>
        <div class="card uper collapse" id="addbrand">
            <div class="card-header">
                Add Brand
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('brands.store')); ?>">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="form-control" name="title" placeholder="Brand Title"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="description" placeholder="Brand Description"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Add</button>
                </form>
            </div>
        </div>


    </div>
    <div class="col-md-8 m-auto">
        <div class="card uper">
            <div class="card-header">
Brands            </div>
            <div class="card-body">

                <table class="table table-striped">
                    <tr>

                        <th>کد</th>
                        <th>نام برند</th>
                    </tr>

                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>


                            <td>

<?php echo e($brand->id); ?>


                            </td>
                            <td>

<?php echo e($brand->title); ?>

<div class="text-left float-left">
    <button class="btn btn-link text-muted" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></button>
    <ul class="dropdown-menu">
        <li><a class="btn btn-link text-warning" href="<?php echo e(route('brands.edit',$brand->id)); ?>">ویرایش برند</a></li>
        <li> <?php echo Form::open(['method' => 'DELETE','route' => ['brands.destroy', $brand->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('حذف برند', ['class' => 'btn btn-link text-danger']); ?>

            <?php echo Form::close(); ?></li>
    </ul>
</div>
                            </td>


                        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>