<?php $__env->startSection('content'); ?>

    <div class="col-md-8 m-auto">
        <button data-toggle="collapse" data-target="#addbrand" class="btn btn-link"><i class="fa fa-plus"></i></button>
        <div class="card uper" id="addbrand">
            <div class="card-header">
                Add Brand
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><br />
                <?php endif; ?>
                    <form method="post" action="<?php echo e(route('brands.update', $brand->id)); ?>">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name="title" placeholder="Brand Title" value="<?php echo e($brand->title); ?>"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="description" placeholder="Brand Description"><?php echo e($brand->description); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>


    </div>
    <div class="col-md-8 m-auto">
        <div class="card uper">
            <div class="card-header">
                Brands            </div>
            <div class="card-body">

                <table class="table table-striped">
                    <tr>

                        <th>کد</th>
                        <th>نام برند</th>
                    </tr>

                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>


                            <td>

                                <?php echo e($b->id); ?>


                            </td>
                            <td>

                                <?php echo e($b->title); ?>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>