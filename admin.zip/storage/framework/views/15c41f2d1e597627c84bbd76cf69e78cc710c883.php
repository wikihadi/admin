<!-- Navbar -->
<nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
<?php echo $__env->make('admincore.topbar.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- SEARCH FORM -->


    <!-- Right navbar links -->
    <ul class="navbar-nav mr-auto">

            
            


        
        
            
                
            
            
                
                
                
            
        


        
        <li class="nav-item animated">
            <a class="nav-link hvr-grow  animated fadeInUp" data-toggle="modal" data-target="#crateStatus" http="#"><i
                        class="fa fa-smile-o"></i></a>
        </li>
        <?php echo $__env->make('statuses.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
            
                        
        
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
                        class="fa fa-bars"></i></a>
        </li>

    </ul>
</nav>
<!-- /.navbar -->
