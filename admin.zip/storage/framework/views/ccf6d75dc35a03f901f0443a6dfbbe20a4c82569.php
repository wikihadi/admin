<?php $__env->startSection('css'); ?>

    <style>
        body, .content-wrapper, .main-heade, .bg-white ,footer{
            background: #2b2a2e!important;
        }
        .border-bottom{
            border-bottom: none!important;
        }
.nav-link{
    color: #888!important;
}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('statuses.modalCreate', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 col-lg-8 col-xl-6 m-auto mt-sm-5" style="">

        <div class="col-md-10 col-lg-8 col-xl-6 m-auto">
        <div class="row m-0">
            
                
                    


                
            
            <?php if(auth()->check() && auth()->user()->hasAnyRole('designer|admin')): ?>
            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/profile" title="" class="btn btn-dark btn-block hvr-grow  animated fadeInDown">صفحه من</a>
                </div>
            </div>
                <?php endif; ?>

            <div class="m-2 col-12"></div>

            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/posts" class="btn btn-info btn-block hvr-grow animated fadeInDown" title="بزودی">اطلاعیه و قوانین</a>
                </div>
            </div>
            <?php if(auth()->check() && auth()->user()->hasAnyRole('designer|admin')): ?>

            <div class="m-2 col-12"></div>
            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/tasks" class="btn btn-success btn-block hvr-grow animated fadeInDown">کارهای من</a>
                </div>
            </div>

            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasAnyRole('modir|admin')): ?>
            <div class="m-2 col-12"></div>
            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/jobs" class="btn btn-success btn-block hvr-grow animated fadeInDown">مشاهده کارها</a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-create')): ?>

            <div class="m-2 col-12"></div>
            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/tasks/create" class="btn btn-warning btn-block hvr-grow animated fadeInDown">کار جدید</a>
                </div>
            </div>
            <?php endif; ?>

            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <div class="m-2 col-12"></div>

            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/all-tasks" class="btn btn-light btn-block hvr-grow animated fadeInDown">همه کارها</a>
                </div>
            </div>
            <div class="m-2 col-12"></div>

            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/users" class="btn btn-light btn-block hvr-grow animated fadeInDown">کاربران</a>
                </div>
            </div>
            <div class="m-2 col-12"></div>

            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/task-meters" class="btn btn-light btn-block hvr-grow animated fadeInDown">Task Meter - موقت</a>
                </div>
            </div>
            <div class="m-2 col-12"></div>

            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a href="/comments" class="btn btn-dark btn-block hvr-grow animated fadeInDown">گفتگوها</a>
                </div>
            </div>
            <?php endif; ?>

            <div class="m-2 col-12"></div>
            <div class="col-12 m-0 p-0">
                <div class="wrimagecard wrimagecard-topimage">
                    <a class="btn btn-danger btn-block hvr-grow animated fadeInDown" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        خروج
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>                </div>
            </div>
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            
            
                
                    
                
            

        </div>
        </div>
        <div class="alert alert-info mt-5 text-center">لطفا در صورت مشاهده هرگونه خطا، از این طریق ما را باخبر نمایید. متشکرم <a href="/tasks/28" class="btn-outline-warning btn">گزارش خطا</a></div>


    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
    <script type="text/javascript" src="/js/status.js"></script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>