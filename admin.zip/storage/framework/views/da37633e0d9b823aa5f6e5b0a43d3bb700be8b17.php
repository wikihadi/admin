<?php $__env->startSection('myNavbar'); ?>

    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style>
        .uper {
            margin-top: 40px;
        }
    </style>
    <main class="py-4" >

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">



                <div class="uper">
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div><br />
                    <?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <td>ID</td>
                            <td>Task Name</td>
                            <td>Task Content</td>
                            <td colspan="2">Action</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($task->id); ?></td>
                                <td><?php echo e($task->title); ?></td>
                                <td><?php echo e($task->content); ?></td>
                                <td><a href="<?php echo e(route('tasks.edit',$task->id)); ?>" class="btn btn-primary">Edit</a></td>
                                <td>
                                    <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                        <?php echo e($tasks->links()); ?>


                        <div>



            </div>
        </div>
    </div>
        </div>
    </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>