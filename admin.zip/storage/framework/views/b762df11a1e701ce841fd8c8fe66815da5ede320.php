
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <?php if(!Request::is('/')): ?><li class="breadcrumb-item"><a href="/">خانه</a></li><?php endif; ?>

                        <?php if(Request::is('users')): ?><li class="breadcrumb-item active">کاربران</li><?php endif; ?>
                        <?php if(Request::is('users/*')): ?><li class="breadcrumb-item"><a href="/users">کاربران</a></li><?php endif; ?>
                        <?php if(Request::is('users/create')): ?><li class="breadcrumb-item active">کاربر جدید</li><?php endif; ?>
                        <?php if(Request::is('users/*/edit')): ?><li class="breadcrumb-item active">ویرایش <?php echo e($user->name); ?></li><?php endif; ?>

                        <?php if(Request::is('tasks')): ?><li class="breadcrumb-item active">کارها</li><?php endif; ?>
                        <?php if(Request::is('tasks/*')): ?><li class="breadcrumb-item"><a href="/tasks">کارها</a></li><?php endif; ?>
                        <?php if(Request::is('tasks/create')): ?><li class="breadcrumb-item active">کار جدید</li><?php endif; ?>
                        <?php if(Request::is('tasks/*/edit')): ?><li class="breadcrumb-item active">ویرایش <?php echo e($task->title); ?></li><?php endif; ?>
                        <?php if(!Request::is('tasks/*/edit') && Request::is('tasks/*') && !Request::is('tasks/create')): ?><li class="breadcrumb-item active"><?php echo e($task->title); ?></li><?php endif; ?>

                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->