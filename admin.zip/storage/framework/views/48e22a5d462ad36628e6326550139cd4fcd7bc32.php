<div class="row  animated fadeIn delay-1s">
    <div class="text-right col">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-create')): ?>
            <a href="/tasks/create" class="btn btn-link" ><i class="fa fa-plus"></i></a>

        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('admin|modir')): ?>
            <?php if(Request::is('pending*')): ?>
                <a href="/jobs" class="btn btn-link"><i class="fa fa-list"></i></a>
            <?php elseif(Request::is('jobs*')): ?>
                <a href="/pending" class="btn btn-link"><i class="fa fa-history"></i></a>
            <?php endif; ?>
        <?php endif; ?>
        <button data-toggle="collapse" href="#users" class="btn btn-link" ><i class="fa fa-users"></i></button>
        <div  id="users" class="collapse show" data-parent="#accordion">
            <div class="d-flex flex-wrap justify-content-center">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mx-2">
                        <?php if(Request::is('*/'.$u->id)): ?>
                                <img src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="" class="img-circle userJobsImageActive animated pulse infinite delay-4s" title="<?php echo e($u->name); ?>" data-toggle="tooltip">
                            <?php else: ?>
                            <a href="/<?php echo e($linked); ?>/<?php echo e($u->id); ?>">
                                <img src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="" class="img-circle userJobsImage hvr-push" title="<?php echo e($u->name); ?>" data-toggle="tooltip">
                            </a>
                            <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

</div>