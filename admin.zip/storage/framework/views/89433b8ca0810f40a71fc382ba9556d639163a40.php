<?php $__env->startSection('myNavbar'); ?>

    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="py-4" >

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">



                <div class="card">
                    <div class="card-header"><?php echo e($task->title); ?>


                        <?php if($dead >= 0): ?>
                            <div class="float-right text-small text-muted"><?php echo e($dead); ?> days remaining</div>
                        <?php else: ?>
                            <div class="float-right text-small text-danger"><?php echo e(abs($dead)); ?> days passed</div>
                        <?php endif; ?>
                    </div>

                    <div class="card-body">
                        <?php echo e($task->content); ?>


                    </div>
                    <div class="card-footer"><?php echo e($task->viewCount); ?> <div class="float-right"><?php echo e($task->commentCount); ?> Comments</div></div>
                </div>
                <div class="card" id="comments">
                    <div class="card-body">


                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-md-2">
                                <img class="rounded-circle img img-fluid" src="/storage/avatars/<?php echo e($comment->user->avatar); ?>" />

                                <p class="text-secondary text-center"><?php echo e($comment->created_at->diffForHumans()); ?></p>
                            </div>
                            <div class="col-md-10">
                                <p>
                                    <a class="float-left" href="#"><strong><?php echo e($comment->user->name); ?></strong></a>
                                    <span class="float-right"><i class="text-warning fa fa-star"></i></span>
                                    <span class="float-right"><i class="text-warning fa fa-star"></i></span>
                                    <span class="float-right"><i class="text-warning fa fa-star"></i></span>
                                    <span class="float-right"><i class="text-warning fa fa-star"></i></span>

                                </p>
                                <div class="clearfix"></div>
                                <p><?php echo e($comment->comment); ?></p>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                    <div class="card">
                        <div class="card-header">Add Comment</div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('comments.store')); ?>">
                            <div class="form-group">
                                <?php echo csrf_field(); ?>
                                <textarea class="form-control" name="comment" placeholder="comment"></textarea>

                            </div>

                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </div>
                    </div>

                    </div>




                    </div>
                </div>
            </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>