<?php $__env->startSection('content'); ?>
    <?php
    $titleOfPage = 'دسته';
    ?>
    <?php if(isset($material) && ($material == '-1')): ?>
        <?php
        $titleOfPage = 'متریال';
        ?>
    <?php endif; ?>
    <?php if(isset($dimen) && ($dimen == '-1')): ?>
        <?php
        $titleOfPage = 'قطع کار';
        ?>
    <?php endif; ?>
    <?php if(isset($type) && ($type == '-1')): ?>
        <?php
        $titleOfPage = 'نوع کار';
        ?>
    <?php endif; ?>
                <div class="col-md-8 m-auto">

                    <button data-toggle="collapse" data-target="#addcat" class="btn btn-link"><i class="fa fa-plus"></i></button>
                    <div class="card uper collapse" id="addcat">
                        <div class="card-header">
                            افزودن <?php echo e($titleOfPage); ?>

                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div><br />
                            <?php endif; ?>
                            <form method="post" action="<?php echo e(route('categories.store')); ?>">
                                <div class="form-group">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" class="form-control" name="title" placeholder="نام <?php echo e($titleOfPage); ?>"/>
                                </div>
                                <?php if(isset($material) && ($material == '-1')): ?>
                                    
                                        
                                    
                                    <input type="hidden"
                                            <?php if(isset($dimen) && ($dimen == '-1')): ?>
                                            name="isDimension"
                                            <?php elseif(isset($type) && ($type == '-1')): ?>
                                           name="isType"
                                           <?php else: ?>
                                           name="isMaterial"

                                            <?php endif; ?>
value="1"/>
                                    <input type="hidden" name="parent_id" value="-1"/>

                                    <?php else: ?>
                                    <div class="form-group">
                                        <label for="">دسته والد</label>
                                        <select name="parent_id" class="form-control">
                                            <option value="0">دسته اصلی</option>
                                            <?php $__currentLoopData = $categories->where('parent_id', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </select>

                                    </div>
                                <?php endif; ?>
                                <button type="submit" class="btn btn-primary btn-block">Add</button>
                            </form>
                        </div>
                    </div>


                </div>
                <div class="col-md-8 m-auto">
                    <div class="card uper">
                        <div class="card-header">
                            <?php echo e($titleOfPage); ?> ها
                        </div>
                        <div class="card-body">

                            <table class="table table-striped">
                                <tr>

                                    <td>کد</td>
                                    <td colspan="2">نام <?php echo e($titleOfPage); ?></td>

                                    
                                    

                                    
                                    

                                </tr>
                                <?php $__currentLoopData = $categories->where('parent_id', -1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <tr>
                                    <td>


                                        <?php echo e($category->id); ?>


                                    </td>
                                    <td><?php echo e($category->title); ?>


                                    </td>
                                    <td>
                                        <div class="dropdown position-absolute">
                                            <button class="btn btn-link text-muted" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></button>
                                            <ul class="dropdown-menu">
                                                <li><a class="btn btn-link text-warning" href="<?php echo e(route('categories.edit',$category->id)); ?>">ویرایش </a></li>
                                                <li> <?php echo Form::open(['method' => 'DELETE','route' => ['categories.destroy', $category->id],'style'=>'display:inline']); ?>

                                                    <?php echo Form::submit('حذف ', ['class' => 'btn btn-link text-danger']); ?>

                                                    <?php echo Form::close(); ?></li>
                                            </ul>
                                        </div>
                                    </td>

                                    

                                        
                                            
                                            
                                                
                                                
                                                    
                                                    
                                                    
                                                
                                                    
                                                
                                            


                                        

                                </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>

                        </div>
                    </div>
                </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>