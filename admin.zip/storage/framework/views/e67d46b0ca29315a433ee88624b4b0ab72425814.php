<div id="collapse<?php echo e($task->id); ?>" class="collapse collapseTask" data-parent="#accordion">
    <div class="card-body">

        <div class="row">
            <div class="col-sm-12 col-md-4 col-xl-3 d-none d-sm-block">
                <img src="/storage/uploads/<?php echo e($task->pic); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-sm-12 col-md-8 col-xl-3 table-responsive">

                <table class="table table-borderless table-striped table-hover text-center  " style="width: 100%;min-width: 100%">

                    <tr>
                        <td><a href="/tasks/<?php echo e($task->id); ?>">کد</a></td>

                        <td><a class="text-muted" href="/tasks/<?php echo e($task->id); ?>"><?php echo e($task->id); ?></a></td>
                    </tr>


                    <tr class="d-md-none">
                        <td>نوع</td>
                        <td><?php echo e($task->type); ?></td>
                    </tr>
                    <tr class="d-md-none">
                        <td>برند</td>
                        <td><?php echo e($task->brand); ?></td>
                    </tr>
                    <tr class="d-md-none">
                        <td>برای</td>
                        <td><?php echo e($task->forProduct); ?></td>
                    </tr>
                    <?php if($task->dx || $task->dy || $task->dz || $task->dDesc): ?>

                        <tr>
                            <td>در قطع</td>
                            <td><span title="عرض"><?php echo e($task->dx); ?></span>-<span title="طول"><?php echo e($task->dy); ?></span>-<span title="عمق"><?php echo e($task->dz); ?></span>-<span title="واحد"><?php echo e($task->dDesc); ?></span>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php if($task->material): ?>

                        <tr>
                            <td>متریال</td>
                            <td><?php echo e($task->material); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr class="d-md-none">
                        <td>مهلت باقیمانده</td>

                        <td>
                            <?php echo e($task->diffDead); ?>

                        </td>
                    </tr>
                    
                    

                    
                    
                    
                    
                    

                    
                    
                    
                    
                    <?php if($task->reTask === 1): ?>
                        <tr>
                            <td colspan="2">مشابه این کار قبلا انجام شده</td>


                        </tr>
                    <?php endif; ?>

                    
                    
                    
                    
                    
                    
                    
                    

                </table>


            </div>
            <div class="col-sm-12 col-md-12 col-xl-6">
                
                

                
                <?php if($task->pending == 0): ?>

                <div class="d-flex justify-content-between"><span class="badge badge-white"><?php echo e($task->jStart); ?></span><span class="badge badge-white"><?php echo e($task->jEnd); ?></span></div>
                <div class="progress">
                    <div data-toggle="tooltip" title="<?php if( $task->prog >100 ): ?>زمان مقرر این تسک پایان یافته است <?php else: ?>زمان سپری شده <?php echo e($task->prog); ?>% <?php endif; ?>"  data-placement="top" class="progress-bar progress-bar-striped <?php if( $task->prog <= 100 ): ?> progress-bar-animated <?php endif; ?> <?php echo e($progbg); ?>"  role="progressbar" style="width: <?php echo e($task->prog); ?>%" aria-valuenow="<?php echo e($task->prog); ?>" aria-valuemin="0" aria-valuemax="100"></div>

                </div>

                <?php endif; ?>

                
                
                
                
                
                
                

                

                
                
                
                

                

                <p class="text-justify pt-3">
                    <?php echo e($task->content); ?>


                </p>


            </div>
            <div class="text-left col-12">
                
                <a href="/tasks/<?php echo e($task->id); ?>" class="btn btn-link"><i class="fa fa-3x fa-arrow-left"></i></a>
            </div>



        </div>
    </div>

</div>
