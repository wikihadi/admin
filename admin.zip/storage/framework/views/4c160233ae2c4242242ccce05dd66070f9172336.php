<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('helper.css.mainTasksCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="col-sm-12">

        <div class="m-0 m-sm-3 p-0 p-sm-5 bg-white" style="border-radius: 30px;">
            <div class="row  animated fadeIn delay-1s">
                <div class="text-right col">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-link"><i class="fa fa-home"></i></a>
                    <a href=".profile" class="btn btn-link" data-toggle="collapse"><i class="fa fa-user"></i></a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-create')): ?>
                        <a href="/tasks/create" class="btn btn-link" ><i class="fa fa-plus"></i></a>

                    <?php endif; ?>
                </div>
                <div class="text-left mb-3 col">
                    <a class="btn btn-link" data-toggle="collapse" href=".collapseTask"><i class="fa fa-arrows-alt"></i></a>

                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <button data-toggle="collapse" data-target="#demo" class="btn btn-link"><i class="fa fa-filter"></i></button>

                    <a href="/users" class="btn btn-link" ><i class="fa fa-users"></i></a>
                    <?php endif; ?>
                </div>
            </div>

            

            
    
                

                    
                        
                    
                

            

<div class="row">
    <div class="col-12 card h2 text-center border-0"><div class="card-header">سوابق عملکرد کاربران</div>
    </div>
    <div class="card-deck">

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-4 col-md-3 col-lg-2">
<div class="card">
    <div class="card-header">
        <img title="<?php echo e($u->name); ?>" class="card-img-top img-fluid img-thumbnail" src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="image" style="width:100%;height: 100%; object-fit: contain" data-toggle="tooltip">

    </div>
    <div class="card-body">
        <u class="list-group m-0 p-0">
            <?php
            $i = 0;
            ?>
            <?php $__currentLoopData = $taskMeters->where('user_id', $u->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/tasks/<?php echo e($t->task_id); ?>" target="_blank"><li class="p-1 text-center list-group-item <?php if($t->end == 1): ?> bg-secondary <?php endif; ?>" <?php if($t->end == 1): ?> title="پایان کار در <?php echo e($t->created_at); ?>" <?php endif; ?>>
                        <?php $__currentLoopData = $tasks->where('id', $t->task_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <small><?php echo e($task->title); ?></small>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($t->end == 1): ?> <i class="fa fa-pause"></i> <?php endif; ?>

                    </li></a>
                <?php
                    $i++;
                ?>
<?php if($i > 5): ?>
                    <?php break; ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </u>
    </div>
    <div class="card-footer"><a href="/users/<?php echo e($u->id); ?>" class="btn btn-link btn-block"><?php echo e($u->name); ?></a></div>
</div>
</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>





                            </div>
                        </div>

                    </div>
                </div>




        </div>


    </div>


    </div>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>