<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('helper.css.createTaskCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-8 m-auto">
        <?php echo $__env->make('helper.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card uper">
            <div class="card-header">
                <div class="float-right">ویرایش <?php echo e($task->id); ?></div>
                <div class="float-left">
                    
                    
                        
                        
                    
                    
                    <span></span>
                </div>
            </div>
            <div class="card-body">
                <?php echo $__env->make('helper.editTask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
    <?php echo $__env->make('helper.js.editTaskJs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>