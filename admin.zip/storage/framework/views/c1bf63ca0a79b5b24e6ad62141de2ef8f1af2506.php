<div class="card-header card-border <?php if($task->isDone == 0): ?><?php echo e($progborder); ?><?php else: ?> bg-success <?php endif; ?>">
    <div class="row">

        <div class="col-md-9 row " data-toggle="collapse" href="#collapse<?php echo e($task->id); ?>">
            
            <div class="col-12 col-md-4 text-center text-md-right "><?php if(isset($task->i)): ?><?php echo e($task->i); ?><?php else: ?><?php echo e($i); ?><?php endif; ?>
                .<?php echo e(str_limit($task->title, 40)); ?></div>
            <div class="d-none d-lg-block col-lg-2 text-center">
                <?php if($task->type && $task->brand != "سایر"): ?>
                    <?php echo e($task->brand); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </div>
            <div class="d-none d-lg-block col-lg-2 text-center">
                <?php if($task->type && $task->type != "سایر"): ?>
                    <?php echo e($task->type); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </div>
            <div class="d-none d-lg-block col-lg-2 text-center">
                <?php if($task->type && $task->forProduct != "سایر"): ?>
                    <?php echo e($task->forProduct); ?>

                <?php else: ?>
                    -
                <?php endif; ?>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <div class="d-none d-lg-block col-lg-2 text-center">

            </div>
        </div>
        <div class="col-md-3 row d-none d-md-flex justify-content-end align-items-center">
            <div class="flex-grow-1">
                <?php if(Request::is('jobs/*')): ?>
                    <form method="post" action="<?php echo e(route('taskorderusers.update', $task->id)); ?>">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                        
                        <button type="submit" class="btn btn-link upKey" name="ordering" value="plus"><i class="fa fa-minus"></i></button>
                        <button type="submit" class="btn btn-link downKey " name="ordering" value="minus"><i class="fa fa-plus"></i></button>
                    </form>
                        
                        
                <?php endif; ?>
            </div>
            <?php if(isset($usersInTasks)): ?>
                <?php $__currentLoopData = $usersInTasks->where('task_id', $task->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $users->where('id', $ut->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mx-1">
                           <img src="/storage/avatars/<?php echo e($u->avatar); ?>" alt="" class="img-circle" style="object-fit: cover; width: 29px;height: 29px; border: 1px solid #a9a9a9;" title="<?php echo e($u->name); ?>" data-toggle="tooltip">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if($task->pending == 0 && $task->isDone == 0): ?>

                <?php if($task->pastOr <= 0): ?>

            <div class="mx-1" title="مهلت" data-toggle="tooltip"><?php echo e($task->diffDead); ?></div>
            <div class="mx-1">
                <i data-toggle="tooltip" title="<?php echo e($task->diffDead); ?>" class="fa animated
                                                <?php if($task->rightNow < 0 ): ?> fa-hourglass-end infinite tada 
                                                <?php elseif($task->rightNow <= 3): ?> fa-hourglass-half rubberBand 
                                                <?php else: ?> fa-hourglass-start rubberBand <?php endif; ?> "></i>
            </div>
                    <?php else: ?>
                    <i data-toggle="tooltip" title="قبل از شروع مقرر" class="fa fa-hourglass-o"></i>
                <?php endif; ?>
            <?php if($task->reTask === 1): ?>
                <div class="mx-1"><i class="fa fa-clone" data-toggle="tooltip" title="Clone"></i></div>
            <?php endif; ?>

            <?php if(isset($taskMeter) && ($taskMeter->end == 0) && ($taskMeter->task_id == $task->id) && ($taskMeter->user_id == $user->id)): ?>
                <div class="mx-1"><a href="/tasks/<?php echo e($task->id); ?>/end"><i class="fa fa-pause"></i></a></div>
            <?php elseif(isset($taskMeter) && $taskMeter->end == 1): ?>
                <div class="mx-1">
                    <a href="/tasks/<?php echo e($task->id); ?>/start"><i class="fa fa-play"></i></a>
                </div>
            <?php endif; ?>

            <?php else: ?>
                <div class="mx-1">در انتظار</div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-edit')): ?>
                    <div class="mx-1 hvr-grow">
                        <a href="/tasks/<?php echo e($task->id); ?>/edit"><i class="fa fa-edit" data-toggle="tooltip" title=" ویرایش <?php echo e($task->title); ?>"></i></a>
                    </div>
                <?php endif; ?>

                    <div class="mx-1 hvr-backward">
                        <a href="/tasks/<?php echo e($task->id); ?>"><i class="fa fa-arrow-left" data-toggle="tooltip" title="برو به <?php echo e($task->title); ?>"></i></a>
                    </div>



        </div>
    </div>
</div>