        

        <?php $__env->startSection('css'); ?>
            <?php echo $__env->make('helper.css.mainTasksCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php $__env->stopSection(); ?>
        
        <?php $__env->startSection('content'); ?>

            <?php echo $__env->make('helper.topNavigateTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('helper.profileTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="col-sm-12">
                    <div class="m-0 m-sm-3 p-0 p-sm-5 bg-white" style="border-radius: 30px;">
                        <?php echo $__env->make('helper.alarm', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <nav class="card-border navbar navbar-expand-sm navbar-light bg-light" data-toggle="affix">
                            <div class="mx-auto d-sm-flex d-block flex-sm-nowrap">
                                <small><a class="navbar-brand" href="#">مرتب سازی:</a></small>

                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample11" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse text-center" id="navbarsExample11">
                                    <ul class="navbar-nav">
                                        <li class="nav-item active">
                                            <small><a class="nav-link" href="/tasks">الویتها</a></small>
                                        </li>
                                        <li class="nav-item">
                                            <small><a class="nav-link" href="/tasks?sort=latest">جدیدترین</a></small>
                                        </li>
                                        
                                            
                                        
                                        <li class="nav-item">
                                            <small><a class="nav-link" href="/tasks?sort=pending">در انتظار</a></small>
                                        </li>
                                        <li class="nav-item">
                                            <small><a class="nav-link" href="/tasks?sort=done">پایان یافته</a></small>
                                        </li>
                                        
                                            
                                        
                                    </ul>
                                </div>
                            </div>
                        </nav>
                        <?php echo $__env->make('helper.navbarTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <?php if($tasks->isEmpty()): ?>
                                <div class="row"><div class="col-sm-6 m-auto m-5"><img class="img-fluid w-100" src="/img/dsp.png" alt=""></div></div>
                            <?php else: ?>

                                <?php if(isset($taskMeter) && $taskMeter->end == 0): ?>
                                    <div class="alert alert-danger"><?php echo e($user->name); ?>، شما یک پروژه باز دارید. تا زمانی که پروژه متوقف نشده یک پروژه جدید باز نکنید. <a href="/tasks/<?php echo e($taskMeter->task_id); ?>" class="btn btn-link">مشاهده</a></div>
                                <?php endif; ?>
                                    <?php echo $__env->make('helper.titleTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endif; ?>
                    <!-----------------must to controller------------------------------->

                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($task->pastOr >= 0): ?>
                                <?php
                                    $progborder = "bg-light";
                                    $progbg = "bg-light";
                                ?>
                            <?php else: ?>
                            <?php if($task->prog <= 20): ?>
                                <?php
                                    $progborder = "bg-light";
                                    $progbg = "bg-info";
                                ?>
                            <?php elseif($task->prog > 20 && $task->prog <= 50): ?>
                                <?php
                                    $progborder = " bg-light";
                                    $progbg = "bg-success";
                                ?>
                            <?php elseif($task->prog > 50 && $task->prog <= 80): ?>
                                <?php
                                    $progborder = " bg-light";
                                    $progbg = "bg-warning";
                                ?>
                            <?php elseif($task->prog > 80 && $task->prog <= 100): ?>
                                <?php
                                    $progborder = "border-danger bg-light";
                                    $progbg = "bg-danger";
                                ?>
                            <?php else: ?>
                                <?php
                                    $progborder = " bg-pink text-dark";
                                    $progbg = "bg-danger";
                                ?>
                            <?php endif; ?>
                            <?php endif; ?>

                            <?php if(isset($taskMeter) && ($taskMeter->end == 0) && ($taskMeter->task_id == $task->id) && ($taskMeter->user_id == $user->id)): ?>
                            <?php elseif(isset($taskMeter) && $taskMeter->end == 1): ?>
                            <?php else: ?>
                                <?php
                                    $progborder = "border-secondary bg-light";
                                    $progbg = "bg-secondary";
                                ?>
                            <?php endif; ?>
                            <?php if($task->pending == 1): ?>
                                    <?php
                                        $progborder = "border-info  bg-info";
                                        $progbg = "bg-info";
                                    ?>
                                <?php endif; ?>

                        <?php echo $__env->make('helper.logicTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <!------------------------------------------------------------------>
                            <div class="card card-border animated fadeInDown" >


                                <?php echo $__env->make('helper.mainlineTask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php echo $__env->make('helper.mainCollapseTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($tasks->links()); ?>

                    </div>
                </div>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('JS'); ?>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>