<div class="row  animated fadeIn delay-1s">
    <div class="text-right col">
        
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task-create')): ?>
            <a href="/tasks/create" class="btn btn-link" ><i class="fa fa-plus"></i></a>

        <?php endif; ?>
    </div>
    <div class="text-left mb-3 col">
        <a class="btn btn-link" data-toggle="collapse" href=".collapseTask"><i class="fa fa-arrows-alt"></i></a>

        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <button data-toggle="collapse" data-target="#demo" class="btn btn-link"><i class="fa fa-filter"></i></button>

        <a href="/users" class="btn btn-link" ><i class="fa fa-users"></i></a>
        <?php endif; ?>
    </div>
</div>