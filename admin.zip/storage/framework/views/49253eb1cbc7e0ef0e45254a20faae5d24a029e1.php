<?php $__env->startSection('content'); ?>
    <div class="col">

        <div class="pull-right">
            <a class="btn btn-link" href="<?php echo e(route('users.create')); ?>"><i class="fa fa-user-plus"></i></a>
        </div>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    



    
    
    
    


    
    


    <div class="col-12">
        <div class=" d-flex flex-wrap justify-content-start">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                    <div class="card">
                        <div class="dropdown position-absolute">
                            <button class="btn btn-link text-muted" type="button" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></button>
                            <ul class="dropdown-menu">
                                <li><a class="btn btn-link text-warning" href="<?php echo e(route('users.edit',$user->id)); ?>">ویرایش کاربر</a></li>
                                <li> <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                                    <?php echo Form::submit('حذف کاربر', ['class' => 'btn btn-link text-danger']); ?>

                                    <?php echo Form::close(); ?></li>
                            </ul>
                        </div>
                        <img class="card-img-top" src="/storage/avatars/<?php echo e($user->avatar); ?>" alt="image" style="width:100%">
                        <div class="card-body pb-3">
                            <table class="table table-borderless table-hover">
                                <tr>
                                    <td>
                                        <a href="/users/<?php echo e($user->id); ?>" ><h4 class="card-text text-center"><?php echo e($user->name); ?></h4></a>
                                    </td>
                                </tr>
                                <?php if(!empty($user->experience)): ?>
                                    <tr>
                                        <td>
                                            <p class="card-text text-center"><?php echo e($user->experience); ?></p>
                                        </td>
                                    </tr>
                                <?php endif; ?>


                                <?php if(!empty($user->getRoleNames())): ?>
                                    <tr>
                                        <td>
                                            <?php if(!empty($user->getRoleNames())): ?>
                                                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="badge badge-success"><?php echo e($v); ?></label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>



                            </table>





                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>