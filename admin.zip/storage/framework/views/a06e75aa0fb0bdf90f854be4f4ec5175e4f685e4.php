<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('helper.css.mainTasksCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

    <style>

        .upDown:last-child form > button.upKey,.upDown:nth-child(4) form > button.downKey
         {
            visibility: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('helper.profileTasks2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-sm-12">

        <div class="m-0 m-sm-3 p-0 p-sm-5 bg-white" style="border-radius: 30px;">

            <?php echo $__env->make('helper.tasksUsers', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if($tasks->isEmpty()): ?>
                <div class="row"><div class="col-sm-6 m-auto m-5"><img class="img-fluid w-100" src="/img/dsp.png" alt=""></div></div>
            <?php else: ?>
                <?php echo $__env->make('helper.titleTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

            <?php echo e(csrf_field()); ?>



            <?php if(Request::is('jobs')): ?>
        <!-----------------must to controller------------------------------->
            <?php
                $i = 1;
            ?>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                <?php if($task->pastOr >= 0): ?>
                    <?php
                        $progborder = "bg-light";
                        $progbg = "bg-light";
                    ?>
                <?php else: ?>
                    <?php if($task->prog <= 20): ?>
                        <?php
                            $progborder = "bg-light";
                            $progbg = "bg-info";
                        ?>
                    <?php elseif($task->prog > 20 && $task->prog <= 50): ?>
                        <?php
                            $progborder = " bg-light";
                            $progbg = "bg-success";
                        ?>
                    <?php elseif($task->prog > 50 && $task->prog <= 80): ?>
                        <?php
                            $progborder = " bg-light";
                            $progbg = "bg-warning";
                        ?>
                    <?php elseif($task->prog > 80 && $task->prog <= 100): ?>
                        <?php
                            $progborder = "border-danger bg-light";
                            $progbg = "bg-danger";
                        ?>
                    <?php else: ?>
                        <?php
                            $progborder = " bg-pink";
                            $progbg = "bg-danger";
                        ?>
                    <?php endif; ?>
                <?php endif; ?>
                    <?php if($task->pending == 1): ?>
                        <?php
                            $progborder = "border-info  bg-info";
                            $progbg = "bg-info";
                        ?>
                    <?php endif; ?>
                <!-----------------must to controller------------------------------->
                <div class="upDown">
                <div class="card card-border animated fadeInDown">

                    <?php echo $__env->make('helper.mainlineTask', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('helper.mainCollapseTasks', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                </div>
                    <?php
                        $i += 1;
                    ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Request::is('jobs/*')): ?>
                <div id='app'>


                    <tasks-component :order="<?php echo e($order); ?>" :tasks="<?php echo e($tasks); ?>" :userInTasks="<?php echo e($usersInTasks); ?>" :allUsers="<?php echo e($users); ?>"></tasks-component>

                </div>
            <?php endif; ?>
            <!---------------------------------------------------------->
            <?php if(isset($task->i)): ?><?php echo e($tasks->links()); ?><?php endif; ?>

        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
    <script src="/js/app.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admincore.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>