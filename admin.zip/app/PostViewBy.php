<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostViewBy extends Model
{
    protected $guarded=[];
}
