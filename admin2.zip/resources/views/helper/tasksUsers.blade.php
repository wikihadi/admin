<div class="row  animated fadeIn delay-1s">
    <div class="text-right col">

        @can('task-create')
            <a href="/tasks/create" class="btn btn-link" ><i class="fa fa-plus"></i></a>

        @endcan
        {{--@role('admin|modir')--}}
            {{--@if(Request::is('pending*'))--}}
                {{--<a href="/jobs" class="btn btn-link"><i class="fa fa-list"></i></a>--}}
            {{--@elseif(Request::is('jobs*'))--}}
                {{--<a href="/pending" class="btn btn-link"><i class="fa fa-history"></i></a>--}}
            {{--@endif--}}
        {{--@endrole--}}
        {{--<button data-toggle="collapse" href="#users" class="btn btn-link" ><i class="fa fa-users"></i></button>--}}
            <a href="/jobs/{{$user->id}}/print" class="btn btn-link"  target="_blank"><i class="fa fa-print"></i></a>

            {{--@if(Request::is('jobs') || isset($jobPage) && $jobPage == 'old')--}}
                {{--<a href="/jobs/{{$user->id}}?pageType=new" class="btn btn-link"><i class="fa fa-key"></i></a>--}}
            {{--@elseif(isset($jobPage) && $jobPage == 'new')--}}
                {{--<a href="/jobs/{{$user->id}}?pageType=old" class="btn btn-link"><i class="fa fa-key"></i></a>--}}
            {{--@endif--}}
        <div  id="users" class="collapse show" data-parent="#accordion">
            <div class="d-flex flex-wrap justify-content-center">



@role('admin|modir')
                <div class="mx-2">
                    <a href="{{url('jobs/all')}}">
                        <svg style="width:100px;height:100px" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M15.6,8.34C16.67,8.34 17.53,9.2 17.53,10.27C17.53,11.34 16.67,12.2 15.6,12.2A1.93,1.93 0 0,1 13.67,10.27C13.66,9.2 14.53,8.34 15.6,8.34M9.6,6.76C10.9,6.76 11.96,7.82 11.96,9.12C11.96,10.42 10.9,11.5 9.6,11.5C8.3,11.5 7.24,10.42 7.24,9.12C7.24,7.81 8.29,6.76 9.6,6.76M9.6,15.89V19.64C7.2,18.89 5.3,17.04 4.46,14.68C5.5,13.56 8.13,13 9.6,13C10.13,13 10.8,13.07 11.5,13.21C9.86,14.08 9.6,15.23 9.6,15.89M12,20C11.72,20 11.46,20 11.2,19.96V15.89C11.2,14.47 14.14,13.76 15.6,13.76C16.67,13.76 18.5,14.15 19.44,14.91C18.27,17.88 15.38,20 12,20Z" />
                        </svg>
                    </a>
                </div>
@endrole


                @foreach($users as $u)

                    <div class="mx-2">

                        {{--<span class="badge badge-info position-absolute"><i class="fa fa-clock-o"></i></span>--}}

                    @if(Request::is('*/'.$u->id))
                            <span class="position-relative">
                                <img src="/storage/avatars/{{ $u->avatar }}" alt="" class="img-circle userJobsImageActive animated pulse infinite delay-4s" title="{{$u->name}}" data-toggle="tooltip">
                            <span class="badge badge-pill badge-success position-absolute" style="right: 10px">{{$u->count}}</span></span>
                            @else
                            <a href="/jobs/{{$u->id}}" class="position-relative">

                                <img src="/storage/avatars/{{ $u->avatar }}" alt="" class="img-circle userJobsImage hvr-push" title="{{$u->name}}" data-toggle="tooltip">
                                <span class="badge badge-pill badge-dark position-absolute" style="right: 10px">{{$u->count}}</span>

                            </a>

                            @endif

                    </div>
                @endforeach

            </div>
        </div>
    </div>

</div>
