<div class="text-right p-3">
    <div style="height: 50px">
        <button class="btn btn-link"><i class="fa fa-bell fa-2x text-info"></i></button>
        {{--<button class="btn btn-link"><i class="fa fa-play-circle fa-2x text-success"></i></button>--}}
        {{--<button class="btn btn-link"><i class="fa fa-pause-circle fa-2x text-warning"></i></button>--}}
        <button class="btn btn-link"><i class="fa fa-stop-circle fa-2x text-danger"></i></button>
        <span class="a-round badge-success p-2">315. برنامه ریزی روی کارهای آتی</span>
    </div>
</div>
