<template>
    
</template>

<script>
    export default {
        name: "Comment"
    }
</script>

<style scoped>

</style>
