<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PressOption extends Model
{
    protected $guarded=[];

}
